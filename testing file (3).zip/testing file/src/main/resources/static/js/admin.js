(function () {

    let adminKey = "";
    let typeChart = null;

    const keyInput = document.getElementById("adminKey");
    const loadBtn = document.getElementById("loadBtn");
    const statusBox = document.getElementById("status");
    const propsBody = document.getElementById("propsBody");
    const inqBody = document.getElementById("inqBody");
    const topList = document.getElementById("topList");

    function esc(text) {
        const div = document.createElement("div");
        div.textContent = text == null ? "" : text;
        return div.innerHTML;
    }

    function say(text, ok) {
        statusBox.textContent = text;
        statusBox.className = ok ? "ok" : "bad";
    }

    function money(p) {
        return "₹" + Number(p).toLocaleString("en-IN");
    }

    function when(iso) {
        return iso ? String(iso).replace("T", " ").slice(0, 16) : "";
    }

    function api(url, options) {
        options = options || {};
        options.headers = Object.assign({ "X-Admin-Key": adminKey }, options.headers || {});
        return fetch(url, options);
    }

    function setText(id, value) {
        document.getElementById(id).textContent = value;
    }

    // ---------- Dashboard ----------

    function renderChart(byType) {

        const canvas = document.getElementById("typeChart");

        // Chart.js internet se aata hai, na aaye to chart chhod do
        if (!window.Chart || !canvas) return;

        if (typeChart) typeChart.destroy();

        typeChart = new Chart(canvas, {
            type: "doughnut",
            data: {
                labels: ["Buy", "Rent", "Commercial"],
                datasets: [{
                    data: [byType.buy || 0, byType.rent || 0, byType.commercial || 0],
                    backgroundColor: ["#1261d8", "#16a34a", "#f59e0b"]
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: { legend: { position: "bottom" } }
            }
        });
    }

    function renderTop(list) {

        if (!list || !list.length) {
            topList.innerHTML = '<li><span class="empty" style="padding:0">No wishlist saves yet.</span></li>';
            return;
        }

        topList.innerHTML = list.map(function (item) {
            return `
            <li>
                <span>${esc(item.title)} <small style="color:#64748b">(id ${esc(item.propertyId)})</small></span>
                <span class="cnt">${esc(item.count)} ${item.count === 1 ? "save" : "saves"}</span>
            </li>`;
        }).join("");
    }

    async function loadStats() {

        const res = await api("/api/admin/stats");

        if (res.status === 403) {
            say("Wrong admin key.", false);
            return false;
        }

        if (!res.ok) {
            say("Could not load the dashboard (status " + res.status + ").", false);
            return false;
        }

        const s = await res.json();

        setText("statProps", s.properties);
        setText("statUsers", s.users);
        setText("statInq", s.enquiries);
        setText("statMsg", s.contactMessages);
        setText("statWish", s.wishlistSaves);

        renderChart(s.byType || {});
        renderTop(s.topWishlisted);

        return true;
    }

    // ---------- Enquiries ----------

    async function loadInquiries() {

        const res = await api("/api/inquiries");

        if (!res.ok) {
            inqBody.innerHTML = '<tr><td colspan="5" class="empty">Could not load enquiries.</td></tr>';
            return;
        }

        const list = await res.json();

        if (!list.length) {
            inqBody.innerHTML = '<tr><td colspan="5" class="empty">No enquiries yet.</td></tr>';
            return;
        }

        inqBody.innerHTML = list.map(function (q) {
            return `
            <tr>
                <td>${esc(when(q.createdAt))}</td>
                <td>${esc(q.name)}</td>
                <td>${esc(q.phone)}</td>
                <td>${esc(q.propertyTitle)}${q.propertyId ? " (id " + esc(q.propertyId) + ")" : ""}</td>
                <td>${esc(q.message)}</td>
            </tr>`;
        }).join("");
    }
        // ---------- Contact messages aur Users ----------

    async function loadMessages() {

        const body = document.getElementById("msgBody");
        const res = await api("/api/admin/contact-messages");

        if (!res.ok) {
            body.innerHTML = '<tr><td colspan="5" class="empty">Could not load messages.</td></tr>';
            return;
        }

        const list = await res.json();

        if (!list.length) {
            body.innerHTML = '<tr><td colspan="5" class="empty">No messages yet.</td></tr>';
            return;
        }

        body.innerHTML = list.map(function (m) {
            return `
            <tr>
                <td>${esc(when(m.createdAt))}</td>
                <td>${esc(m.fullName)}</td>
                <td>${esc(m.email)}<br><small style="color:#64748b">${esc(m.phone)}</small></td>
                <td>${esc(m.subject)}</td>
                <td>${esc(m.message)}</td>
            </tr>`;
        }).join("");
    }

    async function loadUsers() {

        const body = document.getElementById("userBody");
        const res = await api("/api/admin/users");

        if (!res.ok) {
            body.innerHTML = '<tr><td colspan="4" class="empty">Could not load users.</td></tr>';
            return;
        }

        const list = await res.json();

        if (!list.length) {
            body.innerHTML = '<tr><td colspan="4" class="empty">No users yet.</td></tr>';
            return;
        }

        body.innerHTML = list.map(function (u) {
            return `
            <tr>
                <td>${esc(u.id)}</td>
                <td>${esc(u.name)}</td>
                <td>${esc(u.email)}</td>
                <td>${esc(u.phone)}</td>
            </tr>`;
        }).join("");
    }
    // ---------- Properties ----------

    async function loadProperties() {

        const res = await fetch("/api/properties");
        const list = await res.json();

        if (!list.length) {
            propsBody.innerHTML = '<tr><td colspan="6" class="empty">No properties.</td></tr>';
            return;
        }

        propsBody.innerHTML = list.map(function (p) {
            return `
            <tr>
                <td>${esc(p.id)}</td>
                <td>${esc(p.title)}<br><small style="color:#64748b">${esc(p.location)}</small></td>
                <td>${esc(p.type)}</td>
                <td>${money(p.price)}</td>
                <td><input type="checkbox" class="feat-box" data-id="${esc(p.id)}" ${p.featured ? "checked" : ""}></td>
                <td><button type="button" class="danger del-btn" data-id="${esc(p.id)}">Delete</button></td>
            </tr>`;
        }).join("");
    }

    // ---------- Load button ----------

    loadBtn.addEventListener("click", async function () {

        adminKey = keyInput.value;

        if (adminKey === "") {
            say("Please enter the admin key.", false);
            return;
        }

        say("Loading...", true);

        try {
            const ok = await loadStats();
            if (!ok) return;

                      await loadInquiries();
            await loadMessages();
            await loadUsers();
            await loadProperties();
            say("Loaded.", true);

        } catch (err) {
            say("Could not reach the server.", false);
        }
    });

    // ---------- Delete aur Featured ----------

    propsBody.addEventListener("click", async function (event) {

        const btn = event.target.closest(".del-btn");
        if (!btn) return;

        const id = btn.dataset.id;

        if (!confirm("Delete property " + id + "? This cannot be undone.")) return;

        const res = await api("/api/properties/" + id, { method: "DELETE" });

        if (res.ok) {
            say("Property " + id + " deleted.", true);
            loadProperties();
            loadStats();
        } else {
            say("Could not delete (status " + res.status + ").", false);
        }
    });

    propsBody.addEventListener("change", async function (event) {

        const box = event.target.closest(".feat-box");
        if (!box) return;

        const id = box.dataset.id;

        try {
            const current = await (await fetch("/api/properties/" + id)).json();
            current.featured = box.checked;

            const res = await api("/api/properties/" + id, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(current)
            });

            if (res.ok) {
                say("Property " + id + (box.checked ? " is now featured." : " is no longer featured."), true);
            } else {
                box.checked = !box.checked;
                say("Could not update (status " + res.status + ").", false);
            }
        } catch (err) {
            box.checked = !box.checked;
            say("Could not reach the server.", false);
        }
    });

})();